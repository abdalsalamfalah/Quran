from pyrogram import enums
from pyrogram import Client
import sys
app=Client(name="SSESS",session_string=sys.argv[1])

async def main_2():
    try:
        try:
            cht_leave=sys.argv[2]
        except:
            pass
        async with app:
            if await app.leave_chat(cht_leave, delete=True):
                await app.send_message("me","يامرحبا خروج",parse_mode=enums.ParseMode.MARKDOWN)
    except:
        pass
app.run(main_2())