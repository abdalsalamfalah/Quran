from info import *
ST=0
#ST=0  START
#ST=1  GET VIALD NUMBER
#ST=2  SEND CODE TO NUMBER 
#ST=3  VIALD CODE


@bot.message_handler(commands=['start', 'help'])
def handle_start_help(m):
    if ST==0:
        bot.reply_to(m,"مرحبا بارون ارسل رقم الهاتف للتحقق انه صالح")
    else:
        bot.reply_to(m,"هناك رقم يتم التحقق منه حاليا")

@bot.message_handler(func=lambda msg: msg.text.encode("utf-8"))
def send_something(m):
    if ST==1:
        bot.reply_to(m,"GET PHONE NUMBER")
    elif ST==2:
        bot.reply_to(m,"send code to PHONE NUMBER")
    elif ST==3:
        bot.reply_to(m,"vaild code")
  
bot.infinity_polling()