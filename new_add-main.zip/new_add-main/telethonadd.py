import json
import os
import sys
from delete_ban import del_ban
from pyrogram import Client
api_id = 11890730
api_hash ="99932c461a4849544e9c055ec532888c"
from email.message import Message
from itertools import chain
from pyrogram import filters
from pyrogram import Client
from datetime import datetime, timedelta
import asyncio
from pyrogram import enums
list_admin=[806201930,5794398920]
from pyrogram.types import ChatPermissions
app = Client(
    "my_bot",
    api_id=api_id, api_hash=api_hash,
)
usedids=[]
CMDDS="""
`استخدم` : لغرض تحديد الحافظة التي تضم الارقام
`فولدري` : لغرض عرض الحافظة المستخدمة حاليا
`#` : لغرض اضافة الشات الذي نجيب منه اعضاء والشات الي نضيف له اعضاء
`ابد اضافة` : اضافة اعضاء من شات الى شات محددين
! : لغرض اضافة الحسابات 
`انظمام` : لغرض انظمام جميع ارقام القروب الى شات محدد
احذف 111111 : لغرض حذف رقم عن طريق الاب ايدي
ازالة الحسابات المبندة : لغرض ازالة جميع الحسابات المبندة
غادر :  لغرض مغادرة جميع الحسابات الى القروب المحدد
الكروبات : لعرض جميع حافظات الارقام
انشىء حافظة جديدة : لانشاء حافظة ارقام جديدة
"""
from pyrogram.errors import FloodWait
STT_GROP="NO"
usrnum=0
MCHAT="chatadowat"
@app.on_message(filters.text)
async def my_handler(client, message):
    
    if str(message.text)=="GHJ":
        me = await app.get_me()
        SSS=str(me)
        await app.send_message(message.chat.id,f"{SSS}")

    if int(message.from_user.id ) in list_admin:
        global STT_GROP
        #MCHAT=str(message.text).split()[1]
        if str(message.text).startswith("استخدم"):
            # استخدم : لغرض تحديد الحافظة التي تضم الارقام
            try:
                STT_GROP=str(message.text).split()[1]
                await app.send_message(message.chat.id,f"انت الان تستخدم الحافظة :{STT_GROP}")
            except:
                pass
        elif message.text=="عدد":
            ContAccont =len( json.load(open(f"sessions/{STT_GROP}.json")))
            await app.send_message(message.chat.id,f"عدد الحسابات في هذه الحافظة هو:{ContAccont}")
        elif message.text=="فولدري":
            # فولدري : لغرض عرض الحافظة المستخدمة حاليا
            await app.send_message(message.chat.id,f"انت الان في الحافظة :{STT_GROP}")
            
        
        elif str(message.text).startswith('#'):
            # لغرض اضافة الشات الذي نجيب منه اعضاء والشات الي نضيف له اعضاء
            #_____________________>>>>>>>>>>>>>>>>>>
            tmsg=str(message.text).replace('#','')
            msgtrgt=tmsg.split()[0]
            msgplus=tmsg.split()[1]
            chtp=open("chat_plus",'w')
            chtp.write(f"{msgplus}")
            chtp.close()

            chtt=open("chat_traget",'w')
            chtt.write(f"{msgtrgt}")
            chtt.close()
            await app.send_message(message.chat.id,f"تم تعيين شات الهدف الذي هو : {msgtrgt} \nوشات الدعم هو :{msgplus}")
            #_____________________>>>>>>>>>>>>>>>>>>

        elif message.text=="ابدء اضافة":
            # اضافة اعضاء من شات الى شات محددين
            accounts = json.load(open(f"sessions/{STT_GROP}.json"))
            # RUN IT
            for user in accounts :
                a_id = user["API_id"]
                a_hash = user["API_hash"]
                a_strsession = user["STRSESSION"]
                print(os.system(f'python3 add_process.py {a_id} {a_hash} {a_strsession}'))
                print("done")

        elif "!" in message.text:
            #لغرض اضافة الحسابات 
      
                slst=str(message.text).split('!')
                fffffff=open(f"sessions/{STT_GROP}.json")
                nes = json.load(fffffff)
                fffffff.close()
                
                a__id=slst[0]
                a__hash=slst[1]
                a__strsession=slst[2]
                New_item={"API_id":a__id,"API_hash":a__hash,"STRSESSION":a__strsession}
                nes.append(New_item)
                
                with open(f"sessions/{STT_GROP}.json", 'w') as file:
                    json.dump(nes, file)
                await app.send_message(message.chat.id,f"تم اضافة حساب جديد تفاصيله هي : \napi_id:{a__id}\napi_hash:{a__hash}\n\nstring_session:{a__strsession}\n")

     
        elif "تشغيل" in message.text:
            accounts = json.load(open(f"sessions/{STT_GROP}.json"))
            # RUN IT
            for user in accounts :
                a_id = user["API_id"]
                a_hash = user["API_hash"]
                a_strsession = user["STRSESSION"]
                
                os.system(f'python3 startup.py {a_strsession}')
                print("done")
        elif "انضمام" in message.text:
            try:
                chatttt=str(message.text).split()[1]
            except:
                pass
            # لغرض انظمام جميع ارقام القروب الى شات محدد
            accounts = json.load(open(f"sessions/{STT_GROP}.json"))
            # RUN IT
            ii=0
            try:
                for user in accounts :

                    a_id = user["API_id"]
                    a_hash = user["API_hash"]
                    a_strsession = user["STRSESSION"]
                    print(os.system(f'python3 join_to.py {a_strsession} {chatttt}'))
                    ii+=1
                    print("done")
            except:
                pass
            if ii>0:
                await app.send_message(message.chat.id,f"تم انضمام {ii}")
            else:
                await app.send_message(message.chat.id,"لم يتم انضمام اي حساب ")
            
            
        elif str(message.text).startswith("احذف"):
            # لغرض حذف رقم عن طريق app_id
            try:
                accou_id=str(message.text).split()[1]
                del_ban(STT_GROP,accou_id)
                await app.send_message(message.chat.id,f"تم حذف الحساب رقم المعرف هو :{accou_id}")
            except:
                print("ERROR DELETE ACCOUNT")
                
        elif message.text=="ازالة الحسابات المبندة":
            # لغرض ازالة جميع الحسابات المبندة
            fle=open("ban_list.txt","r")
            file_acounts=fle.readlines()
            fle.close()
            for iacont in file_acounts:
                try:
                    accou_id=str(message.text).split()[1]
                    del_ban(STT_GROP,str(iacont).replace("\n",""))
                except:
                    print("ERROR DELETE ACCOUNT")
        elif "غادر" in message.text:
            # لغرض مغادرة جميع الحسابات الى القروب المحدد
            try:
                chatttt_l=str(message.text).split()[1]
            except:
                pass
            accounts = json.load(open(f"sessions/{STT_GROP}.json"))
            # RUN IT
            for user in accounts :
                a_id = user["API_id"]
                a_hash = user["API_hash"]
                a_strsession = user["STRSESSION"]
                os.system(f'python3 join_to.py {a_strsession} {chatttt_l}')
                print("done")  
            if ii>0:
                await app.send_message(message.chat.id,f"تم مغادرة {ii}")
            else:
                await app.send_message(message.chat.id,"لم يتم مغادرة اي حساب ")
            
        #await app.leave_chat(chat_id, delete=True)



        elif message.text=="الاوامر":
            await app.send_message(message.chat.id,f"قائمة الأوامر \n{CMDDS}",parse_mode=enums.ParseMode.HTML)
        elif message.text=="الكروبات":
            # لعرض جميع حافظات الارقام
            s=""
            list_grops_string=os.listdir("sessions/")
            for ii in list_grops_string:
                s+=f"الكروب :{ii.strip('.json')} \n"
            s+="."
            await app.send_message(message.chat.id,s)

            list_grops_string.clear()


        if message.text=="انشىء حافظة جديدة":
            # لانشاء حافظة الارقام جديدة
            list_grops=os.listdir("sessions/")
            count_list=len(list_grops)
            FN=f"G{count_list+1}.json"
            if FN not in list_grops:
                FILE_NEWW=open(f"sessions/{FN}","a")
                FILE_NEWW.write("[]")
                FILE_NEWW.close()
                print("Created Gruop")
                await app.send_message(message.chat.id,f"تم انشاء حافظة جديدة تحت اسم {FN}")

            else:
                FN=f"G{count_list+2}.json"
                FILE_NEWW=open(f"sessions/{FN}","a")
                FILE_NEWW.write("[]")
                FILE_NEWW.close()
                print("Created Gruop")
            list_grops.clear()

app.run()