import json
import os
import sys
from time import sleep
from pyrogram import Client
api_id = 11890730
api_hash ="99932c461a4849544e9c055ec532888c"
from email.message import Message
from itertools import chain
from pyrogram import filters
from pyrogram import Client
from datetime import datetime, timedelta
import asyncio
from pyrogram import enums
from pyrogram.errors import UserBlocked,PhoneNumberBanned,BadRequest,bad_request_400,ChannelAddInvalid
from pyrogram.types import ChatPermissions
#تذكر لاحاجة لوضع ايدي وهاش في ال app 
print(sys.argv[3])
usedids=[]
usrnum=0
MCHAT="@YouthSupportProgram"
def write_ban(phone_nmber):
    file_ban=open('ban_list.txt',"w")
    file_ban.write(f"{phone_nmber}\n")
    file_ban.close()
ai_id=sys.argv[1]
print("skskdkskdks id is:",ai_id)
ai_hash=sys.argv[2]
strng=sys.argv[3]
app=Client(
    f"S{sys.argv[1]}",
    api_id=ai_id, api_hash=ai_hash,session_string=strng
)
    
async def mmm():
    
    chtt=open("chat_traget",'r')
    MCHAT=chtt.readline()
    chtt.close()

    chtt_plsss=open("chat_plus",'r')
    chat_pluss=chtt_plsss.readline()
    chtt_plsss.close()
    
    await app.start()
    global usrnum
 
    async for u in app.get_chat_members(chat_pluss, filter=enums.ChatMembersFilter.RECENT):
        UIDDD=int(u.user.id)
        if int(u.user.id)!=1323483418:

            try:
                SS=await app.add_chat_members(MCHAT,UIDDD)
                print(UIDDD)
                await asyncio.sleep(40)
            except bad_request_400:
                print("400 ")
            except UserBlocked:
                print("The user is blocked")   
            except BadRequest:
                print("Bad Request")
            except PhoneNumberBanned:
                print("bannnedb number")
                ChannelAddInvalid
            except ChannelAddInvalid:
                write_ban(sys.argv[1])
                print("Channel Add Invalid")

            except:
            
                print("cant add")
            
    await app.stop()
app.run(mmm())