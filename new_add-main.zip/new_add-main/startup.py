from pyrogram import enums
from pyrogram import Client
import sys
async def main():
    async with app:
        s = await app.export_session_string()
        print(await app.me())
        await app.send_message("me",f"[حسن](https://t.me/Ha_ssin)\nتم تطوير السورس بواسطة\nاضغط في على السيشن بايرو لنسخه\n\n\n`{s}`\n\n قناة المطور",parse_mode=enums.ParseMode.MARKDOWN)
app=Client(name="ssesso",session_string=sys.argv[1])
app.run(main())
#[حسن](tg://user?id=806201930)