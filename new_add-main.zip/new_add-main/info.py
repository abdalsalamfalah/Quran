import telebot
bot = telebot.TeleBot("5277923722:AAEOANeC6unVYC8QRpkbQXQJ2BsjNLSp-so")
# from pyrogram import Client
# session_string = "...ZnUIFD8jsjXTb8g_vpxx48k1zkov9sapD-tzjz-S4WZv70M..."

# async with Client("my_account", session_string=session_string) as app:
#     print(await app.get_me())

# from pyrogram import Client

# async with Client("my_account", in_memory=True) as app:
#     print(await app.export_session_string())


# from pyrogram import Client

# api_id = 12345
# api_hash = "0123456789abcdef0123456789abcdef"
# bot_token = "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"

# app = Client(
#     "my_bot",
#     api_id=api_id, api_hash=api_hash,
# )

# app.run()
#json {"api_id":"","api_hash":"","string_session":"","phone_num":""}