import json
def del_ban(filee,id_appp):
    
    file_name = f'sessions/{filee}.json'

    with open(file_name, 'r', encoding='utf-8') as f:
        my_list = json.load(f)
        for idx, obj in enumerate(my_list):
            if obj['API_id'] == id_appp:
                my_list.pop(idx)

    new_file_name = f'sessions/{filee}.json'

    with open(new_file_name, 'w', encoding='utf-8') as f:
        f.write(json.dumps(my_list, indent=2))
#del_ban("G1","11890730")
